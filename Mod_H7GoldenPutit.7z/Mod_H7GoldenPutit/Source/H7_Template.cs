using BepInEx;
using HarmonyLib;
using System.Collections.Generic;
using System.IO;

namespace Mod
{
    [BepInPlugin("H7.GoldenPutit", "H7GoldenPutit", "1.0.0")]
    public class Main : BaseUnityPlugin
    {
        void Awake()
        {
            var harmony = new Harmony("H7.GoldenPutit");
            harmony.PatchAll();
        }

        public void OnStartCore()
        {
            var dir = Path.GetDirectoryName(Info.Location);
            var excel = Path.Combine(dir, "GoldenPootit.xlsx");
            var sources = Core.Instance.sources;
            ModUtil.ImportExcel(excel, "Chara", sources.charas);
        }
    }
}
