using BepInEx;
using HarmonyLib;

namespace Mod;

[BepInPlugin("H7.CSPartPicker", "Less Chaotic Shapes", "0.1.0")]
public class Main : BaseUnityPlugin
{
	private void Awake()
	{
		//IL_0006: Unknown result type (might be due to invalid IL or missing references)
		//IL_000c: Expected O, but got Unknown
		Harmony val = new Harmony("H7.CSPartPicker");
		val.PatchAll();
	}
}
