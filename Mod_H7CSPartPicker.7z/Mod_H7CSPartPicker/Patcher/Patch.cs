using System;
using System.Collections.Generic;
using System.Linq;
using HarmonyLib;
using BepInEx;

namespace Patcher;

[HarmonyPatch]
public class Patch
{
	private class BodyPartOption
	{
		public int ElementId { get; }

		public string Name { get; }

		public BodyPartOption(int elementId, string name)
		{
			ElementId = elementId;
			Name = name;
		}
	}

	private static readonly Dictionary<int, string> bodyPartOptions = new Dictionary<int, string>
	{
		{ 30, "Head" },
		{ 31, "Neck" },
		{ 33, "Back" },
		{ 34, "Arm" },
		{ 35, "Hand" },
		{ 36, "Finger" },
		{ 37, "Waist" },
		{ 39, "Foot" }
	};

	[HarmonyPrefix]
	[HarmonyPatch(typeof(Chara), "AddRandomBodyPart")]
	public static bool Prefix_AddRandomBodyPart(ref Chara __instance, bool msg)
	{
		if (!((Card)__instance).IsPC)
		{
			return true;
		}
		List<BodyPartOption> options = bodyPartOptions.Select<KeyValuePair<int, string>, BodyPartOption>((KeyValuePair<int, string> kvp) => new BodyPartOption(kvp.Key, (Element.Get(kvp.Key)).GetName())).ToList();
		ShowBodyPartSelectionDialog(__instance, options, msg);
		return false;
	}

	private static void ShowBodyPartSelectionDialog(Chara character, List<BodyPartOption> options, bool showMessage)
	{
		Dialog.List<BodyPartOption>("Select Body Part", (ICollection<BodyPartOption>)options, (Func<BodyPartOption, string>)((BodyPartOption item) => item.Name), (Func<int, string, bool>)delegate(int index, string name)
		{
			int elementId = options[index].ElementId;
			character.body.AddBodyPart(elementId, (Thing)null);
            if (showMessage)
			{
				((Card)character).Say("gain_bodyparts", (Card)(object)character, (Element.Get(elementId)).GetName().ToLower(), (string)null);
				((Card)character).PlaySound("offering", 1f, true);
			}
			return true;
		}, false);
	}
}
