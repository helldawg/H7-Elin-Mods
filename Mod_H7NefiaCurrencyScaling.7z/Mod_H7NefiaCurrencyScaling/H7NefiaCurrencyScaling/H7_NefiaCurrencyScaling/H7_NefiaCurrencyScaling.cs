﻿using BepInEx;
using HarmonyLib;
using BepInEx.Configuration;
using UnityEngine;

namespace Mod
{
    [BepInPlugin("H7.NefiaCurrencyScaling", "H7 Mo' Levels Mo' Oren", "0.1.0")]
    public class Main : BaseUnityPlugin
    {
        // Oren Config
        public static ConfigEntry<float> MaxOrenMultiplier;
        public static ConfigEntry<int> MaxOrenLevel;

        // Platinum Config
        public static ConfigEntry<float> MaxPlatMultiplier;
        public static ConfigEntry<int> MaxPlatLevel;
        public static ConfigEntry<int> MaxPlatAmount;

        // Medal Config
        public static ConfigEntry<int> NefiaLevelsPerBonusMedal;
        public static ConfigEntry<int> BonusMedalCount;
        public static ConfigEntry<bool> SeparateMedalReward;
        public static ConfigEntry<int> MedalChanceBonusStartLevel;
        public static ConfigEntry<float> MedalChanceBonusPerLevel;

        private void Awake()
        {
            // Oren settings
            MaxOrenMultiplier = Config.Bind("#Orens", "MaxOrenMultiplier", 3.0f, "Maximum oren multiplier");
            MaxOrenLevel = Config.Bind("#Orens", "MaxOrenLevel", 40, "Nefia level at which maximum oren multiplier is reached");

            // Platinum settings
            MaxPlatMultiplier = Config.Bind("#Platinum", "MaxPlatMultiplier", 2.5f, "Maximum platinum multiplier");
            MaxPlatLevel = Config.Bind("#Platinum", "MaxPlatLevel", 50, "Nefia level at which maximum platinum multiplier is reached");
            MaxPlatAmount = Config.Bind("#Platinum", "MaxPlatAmount", 30, "Absolute maximum platinum amount regardless of level");

            // Medal settings
            NefiaLevelsPerBonusMedal = Config.Bind("#Medals", "NefiaLevelsPerBonusMedal", 5, "Nefia levels per bonus medal");
            BonusMedalCount = Config.Bind("#Medals", "BonusMedalCount", 1, "Number of bonus medals");
            SeparateMedalReward = Config.Bind("#Medals", "SeparateMedalReward", true, "Separate medal reward from treasure map and skill book rewards. When set to false, you can only get one of the three. This setting makes it so you can get both small medals AND a treasure map OR skill book");
            MedalChanceBonusStartLevel = Config.Bind("#Medals", "MedalChanceBonusStartLevel", 15, "Nefia level at which bonus medal chance starts increasing");
            MedalChanceBonusPerLevel = Config.Bind("#Medals", "MedalChanceBonusPerLevel", 0.5f, "Additional % chance to get medals per Nefia level above MedalChanceBonusStartLevel. Vanilla chance is 20%");

            Harmony harmony = new Harmony("H7.NefiaCurrencyScaling");
            harmony.PatchAll();
        }
    }
}

namespace Patcher
{
    [HarmonyPatch]
    public class Patch
    {
        [HarmonyPrefix]
        [HarmonyPatch(typeof(ThingGen), "CreateTreasureContent")]
        public static bool Prefix_CreateTreasureContent(Thing t, int lv, TreasureType type, bool clearContent)
        {
            if (type != TreasureType.BossNefia)
            {
                return true;
            }

            int nefiaLevel = Mathf.Abs(EClass._zone.lv);
            int miracleChance = lv;
            int num = EClass.curve(lv, 20, 15);
            bool flag = true;
            bool flag2 = true;
            int guaranteedMythical = ((type == TreasureType.BossQuest) ? 1 : 0);
            ChangeSeed();
            t.AddEditorTag(EditorTag.PreciousContainer);
            if (clearContent)
            {
                t.things.DestroyAll();
            }

            float OrenMultiplier = 1.0f + Mathf.Min(Mod.Main.MaxOrenMultiplier.Value, ((float)nefiaLevel / (float)Mod.Main.MaxOrenLevel.Value) * (Mod.Main.MaxOrenMultiplier.Value - 1.0f));
            int OrenAmount = (int)(EClass.rndHalf(500 + num * 50) * OrenMultiplier);
            t.Add("money", OrenAmount);

            // Apply scaled platinum based on Nefia level
            float platMultiplier = 1.0f + Mathf.Min(Mod.Main.MaxPlatMultiplier.Value, ((float)nefiaLevel / (float)Mod.Main.MaxPlatLevel.Value) * (Mod.Main.MaxPlatMultiplier.Value - 1.0f));
            int platBase = Mathf.Min(3 + num / 10, Mod.Main.MaxPlatAmount.Value);
            int platAmount = Mathf.Min(Mod.Main.MaxPlatAmount.Value, (int)(EClass.rndHalf(platBase) * platMultiplier));
            t.Add("plat", platAmount);

            t.Add("rp_random", 1, lv);

            float MedalBonusChance = Mod.Main.MedalChanceBonusPerLevel.Value * Mathf.Max(0.0f, (float)(nefiaLevel - Mod.Main.MedalChanceBonusStartLevel.Value));
            int BonusMedals = Mod.Main.BonusMedalCount.Value * Mathf.FloorToInt((float)nefiaLevel / (float)Mod.Main.NefiaLevelsPerBonusMedal.Value);
            int MedalChance = Mathf.CeilToInt(20.0f + MedalBonusChance);
            if (Mod.Main.SeparateMedalReward.Value)
            {
                if (EClass.rnd(100) <= MedalChance)
                {
                    t.Add("medal", EClass.rnd(3) + BonusMedals);
                }
                if (EClass.rnd(3) == 0)
                {
                    t.Add("map_treasure", 1, EClass.rndHalf(lv + 10));
                }
                else
                {
                    t.Add("book_skill", 1, lv);
                }
            }
            else
            {
                if (EClass.rnd(100) <= MedalChance)
                {
                    t.Add("medal", EClass.rnd(3) + BonusMedals);
                }
                else if (EClass.rnd(3) == 0)
                {
                    t.Add("map_treasure", 1, EClass.rndHalf(lv + 10));
                }
                else
                {
                    t.Add("book_skill", 1, lv);
                }
            }

            t.c_lockLv /= 2;

            if (EClass.rnd(3) == 0)
            {
                t.Add("rp_random", 1, lv);
            }
            else if (type != TreasureType.Map && EClass.rnd(2) == 0)
            {
                Thing thing = ThingGen.CreateFromCategory("furniture", lv);
                if (!thing.IsContainer && (t.c_lockLv == 0 || thing.SelfWeight < 10000))
                {
                    t.AddCard(thing);
                }
            }
            else
            {
                t.AddCard(ThingGen.CreateFromCategory("junk", lv));
            }

            if (EClass.rnd(3) == 0)
            {
                t.Add("book_ancient", 1, lv);
            }

            if (t.c_lockLv > 0)
            {
                miracleChance += 20 + (int)Mathf.Sqrt(t.c_lockLv * 5);
            }

            if (flag)
            {
                SetRarity(100);
                t.AddCard(ThingGen.CreateFromFilter("eq", lv));

                if (flag2)
                {
                    SetRarity(20);
                    t.AddCard(ThingGen.CreateFromFilter("eq", lv));
                }
            }

            Rand.SetSeed();
            static void ChangeSeed()
            {
                EClass.player.seedChest++;
                Rand.SetSeed(EClass.game.seed + EClass.player.seedChest);
            }

            void SetRarity(int mtp)
            {
                ChangeSeed();
                Rarity rarity = ((miracleChance * mtp / 100 < EClass.rnd(100)) ? Rarity.Superior :
                                ((EClass.rnd(20) == 0) ? Rarity.Mythical : Rarity.Legendary));

                if (guaranteedMythical > 0)
                {
                    guaranteedMythical--;
                    rarity = Rarity.Mythical;
                }

                CardBlueprint.Set(new CardBlueprint { rarity = rarity });
            }
            return false;
        }
    }
}
